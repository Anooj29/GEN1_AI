from flask import Flask, request, jsonify, render_template
import pickle
import numpy as np

app = Flask(__name__)

model_path = "model.pkl"
model = pickle.load(open(model_path, "rb"))

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/predict', methods=['POST'])
def predict():
    try:
        account_number = request.form['account_number']
        onus_attributes = request.form['onus_attributes']
        transaction_attributes = request.form['transaction_attributes']
        bureau_attributes = request.form['bureau_attributes']
        bureau_enquiry_attributes = request.form['bureau_enquiry_attributes']

        onus_attributes = list(map(float, onus_attributes.split(',')))
        transaction_attributes = list(map(float, transaction_attributes.split(',')))
        bureau_attributes = list(map(float, bureau_attributes.split(',')))
        bureau_enquiry_attributes = list(map(float, bureau_enquiry_attributes.split(',')))

        features = np.array(onus_attributes + transaction_attributes + bureau_attributes + bureau_enquiry_attributes).reshape(1, -1)

        prediction = model.predict(features)[0]
        probability = model.predict_proba(features)[0][1]

        result = {
            "account_number": account_number,
            "default_probability": probability,
            "prediction": "Default" if prediction == 1 else "No Default"
        }
        return jsonify(result)
    except Exception as e:
        return jsonify({"error": str(e)})

if __name__ == '__main__':
    app.run(debug=True)
